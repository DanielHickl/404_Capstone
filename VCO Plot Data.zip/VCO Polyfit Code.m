%% VCO Fq vs Vtune Plot Extraction %%

% README: 
% This MATLAB code extracts the Fq vs Vtune plot from the VCO
%datasheet to create a line of best fit. This line of best fit is used to
%help calibrate the DAC in creating the most linear output RF signal.


% Reference Image to Extract
img = imread('Vtune vs Fq Plot.png');
figure,imshow(img);

% Read the CSV file into a table
data = readmatrix('Vtune Plot Points.csv');

% Extract the x and y values
x = data(:, 1);  
y = data(:, 2); 

% Plot the original data points
figure;
scatter(x, y, 'b', 'DisplayName', 'Data Points');
xlabel('Tuning Voltage (V)');
ylabel('Frequency (GHz)');
title('Frequency vs Vtune Extraction Plot');
hold on; 

% Fit a polynomial regression model
p = polyfit(x, y, 3);   %regressional model to 3rd order

% Generate y-values based on the polynomial fit
y_fit = polyval(p, x);  % Evaluate the polynomial at the x values

% Plot the fitted polynomial curve
plot(x, y_fit, 'LineWidth', 2, 'DisplayName', 'Polynomial Fit (Order 3)');
hold off;

% Print the polynomial coefficients
disp('Polynomial Coefficients:');
disp(p);   %first term is highest order, so ax^3 + bx^2 + cx + d








